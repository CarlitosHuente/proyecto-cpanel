# huente_app
Aplicacion para los Informes.

#Actualizar Github
git add .
git commit -m "Primer cambio desde VS Code"
git push origin main
git push origin main --force


# Crear CArpeta Local

python -m venv venv

# y dependencias 
pip install -r requirements.txt


# Activar LocalHost

.\venv\Scripts\activate


# y ejecutar la app
python app.py

#